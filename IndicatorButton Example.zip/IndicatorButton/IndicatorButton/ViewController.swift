//
//  ViewController.swift
//  IndicatorButton
//
//  Created by Alfredo Uzumaki on 5/2/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var shakeOnCancelSwitch: UISwitch!
    @IBOutlet weak var isCancelableSwitch: UISwitch!
    
    @IBOutlet weak var testButton: IndicatorButton!
    @IBAction func testButtonAction(_ sender: Any) {
        testButton.isCancelabel = isCancelableSwitch.isOn
        testButton.isLoading ? testButton.stopLoading(withShake: shakeOnCancelSwitch.isOn) : testButton.startLoading()
    }
    @IBAction func enableButtonAction(_ sender: Any) {
        testButton.setEnable()
    }
    @IBAction func disableButtonAction(_ sender: Any) {
        testButton.setDisable()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        testButton.layer.cornerRadius = testButton.frame.height / 2
    }
}

